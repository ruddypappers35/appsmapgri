
-- Add category column to menu_items table
ALTER TABLE menu_items ADD COLUMN category text DEFAULT 'Umum';

-- Update existing items to have a default category
UPDATE menu_items SET category = 'Umum' WHERE category IS NULL;
