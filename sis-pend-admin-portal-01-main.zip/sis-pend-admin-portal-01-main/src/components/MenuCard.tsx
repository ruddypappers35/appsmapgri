
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Edit, Trash2 } from "lucide-react";

interface MenuItem {
  id: string;
  name: string;
  url: string;
  icon: string;
  description?: string;
  category: string;
}

interface MenuCardProps {
  item: MenuItem;
  isAdminMode: boolean;
  onEdit: (item: MenuItem) => void;
  onDelete: (id: string) => void;
}

const MenuCard: React.FC<MenuCardProps> = ({
  item,
  isAdminMode,
  onEdit,
  onDelete
}) => {
  return (
    <Card 
      className="group hover:shadow-lg transition-all duration-300 cursor-pointer bg-white border-gray-200 hover:border-blue-300 hover:scale-105"
      onClick={() => window.open(item.url, '_blank')}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start space-x-3">
          <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center text-xl shadow-md group-hover:shadow-lg transition-all duration-300 group-hover:scale-110 flex-shrink-0">
            {item.icon ? (
              <i className={`${item.icon} text-white`}></i>
            ) : (
              <i className="fas fa-file-alt text-white"></i>
            )}
          </div>
          <div className="flex-1 text-left">
            <CardTitle className="text-sm font-semibold text-gray-900 leading-tight group-hover:text-blue-700 transition-colors mb-1">
              {item.name}
            </CardTitle>
            {item.description && (
              <p className="text-xs text-gray-600 leading-relaxed">{item.description}</p>
            )}
          </div>
        </div>
      </CardHeader>
      
      {isAdminMode && (
        <CardContent className="pt-0">
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1 hover:bg-blue-50 border-blue-200" 
              onClick={(e) => {
                e.stopPropagation();
                onEdit(item);
              }}
            >
              <Edit className="w-3 h-3 mr-1" />
              Edit
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex-1 hover:bg-red-50 border-red-200"
              onClick={(e) => {
                e.stopPropagation();
                onDelete(item.id);
              }}
            >
              <Trash2 className="w-3 h-3 mr-1" />
              Hapus
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
};

export default MenuCard;
