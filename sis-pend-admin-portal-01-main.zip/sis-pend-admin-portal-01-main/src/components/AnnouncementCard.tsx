
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Edit, Trash2 } from "lucide-react";

interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
  isImportant: boolean;
}

interface AnnouncementCardProps {
  announcement: Announcement;
  isAdminMode: boolean;
  onEdit: (announcement: Announcement) => void;
  onDelete: (id: string) => void;
  onClick: (announcement: Announcement) => void;
}

const AnnouncementCard: React.FC<AnnouncementCardProps> = ({
  announcement,
  isAdminMode,
  onEdit,
  onDelete,
  onClick
}) => {
  // Extract text content from HTML
  const getPlainTextPreview = (html: string) => {
    const div = document.createElement('div');
    div.innerHTML = html;
    return div.textContent || div.innerText || '';
  };

  const plainTextContent = getPlainTextPreview(announcement.content);
  const preview = plainTextContent.length > 120 
    ? plainTextContent.substring(0, 120) + '...' 
    : plainTextContent;

  return (
    <Card 
      className={`${
        announcement.isImportant 
          ? 'border-orange-200 bg-gradient-to-r from-orange-50 to-orange-100' 
          : 'bg-white hover:bg-blue-50'
      } hover:shadow-lg transition-all duration-300 cursor-pointer border-l-4 ${
        announcement.isImportant ? 'border-l-orange-500' : 'border-l-blue-500'
      }`}
      onClick={() => onClick(announcement)}
    >
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-3">
              <h4 className="font-semibold text-slate-900 text-base line-clamp-2">
                {announcement.title}
              </h4>
              {announcement.isImportant && (
                <Badge className="bg-orange-500 text-white border-orange-600 px-2 py-1">
                  <i className="fas fa-exclamation-triangle mr-1 text-xs"></i>
                  Penting
                </Badge>
              )}
            </div>
            <p className="text-slate-600 mb-3 line-clamp-3 leading-relaxed text-sm">
              {preview}
            </p>
            <div className="flex items-center text-sm text-slate-500">
              <i className="fas fa-calendar-alt mr-2 text-blue-500"></i>
              {new Date(announcement.date).toLocaleDateString('id-ID', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </div>
          </div>
          {isAdminMode && (
            <div className="flex space-x-2 ml-4">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={(e) => {
                  e.stopPropagation();
                  onEdit(announcement);
                }}
                className="hover:bg-blue-50"
              >
                <Edit className="w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(announcement.id);
                }}
                className="hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default AnnouncementCard;
