import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Settings, Plus, Megaphone, Search, Users, BookOpen, Info, User, FileText, Bell } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import RichTextEditor from "@/components/RichTextEditor";
import AnnouncementCard from "@/components/AnnouncementCard";
import MenuCard from "@/components/MenuCard";

interface MenuItem {
  id: string;
  name: string;
  url: string;
  icon: string;
  description?: string;
  category: string;
}

interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
  isImportant: boolean;
}

const Index = () => {
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [adminPassword, setAdminPassword] = useState("");
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const [newMenuItem, setNewMenuItem] = useState({
    name: "",
    url: "",
    icon: "",
    description: "",
    category: ""
  });

  const [newAnnouncement, setNewAnnouncement] = useState({
    title: "",
    content: "",
    isImportant: false
  });

  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Announcement | null>(null);
  const [showAnnouncements, setShowAnnouncements] = useState(false);

  // Load data from Supabase on component mount
  useEffect(() => {
    loadMenuItems();
    loadAnnouncements();
  }, []);

  const loadMenuItems = async () => {
    try {
      const { data, error } = await supabase
        .from('menu_items')
        .select('*')
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error loading menu items:', error);
        toast({
          title: "Error",
          description: "Gagal memuat data menu",
          variant: "destructive"
        });
      } else if (data) {
        const formattedItems = data.map(item => ({
          id: item.id,
          name: item.name,
          url: item.url,
          icon: item.icon || "",
          description: item.description || "",
          category: item.category || "Umum"
        }));
        setMenuItems(formattedItems);
      }
    } catch (error) {
      console.error('Error loading menu items:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadAnnouncements = async () => {
    try {
      const { data, error } = await supabase
        .from('announcements')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error loading announcements:', error);
        toast({
          title: "Error",
          description: "Gagal memuat data pengumuman",
          variant: "destructive"
        });
      } else if (data) {
        const formattedAnnouncements = data.map(item => ({
          id: item.id,
          title: item.title,
          content: item.content,
          date: item.date,
          isImportant: item.is_important
        }));
        setAnnouncements(formattedAnnouncements);
      }
    } catch (error) {
      console.error('Error loading announcements:', error);
    }
  };

  // Helper function to check if announcement is new (within 7 days)
  const isNewAnnouncement = (date: string) => {
    const announcementDate = new Date(date);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - announcementDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 7;
  };

  // Filter menu items based on search query
  const filteredMenuItems = menuItems.filter(item =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Group filtered menu items by category
  const groupedMenuItems = filteredMenuItems.reduce((acc, item) => {
    const category = item.category || "Umum";
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(item);
    return acc;
  }, {} as Record<string, MenuItem[]>);

  const handleAdminLogin = () => {
    if (adminPassword === "Ryuna0106") {
      setIsAdminMode(true);
      setAdminPassword("");
      toast({
        title: "Login berhasil",
        description: "Selamat datang di panel admin SISPENDA"
      });
    } else {
      toast({
        title: "Login gagal",
        description: "Password admin tidak valid",
        variant: "destructive"
      });
    }
  };

  const handleAddMenuItem = async () => {
    if (!newMenuItem.name || !newMenuItem.url || !newMenuItem.category) {
      toast({
        title: "Error",
        description: "Nama menu, URL, dan kategori harus diisi",
        variant: "destructive"
      });
      return;
    }

    try {
      const { data, error } = await supabase
        .from('menu_items')
        .insert([{
          name: newMenuItem.name,
          url: newMenuItem.url,
          icon: newMenuItem.icon,
          description: newMenuItem.description,
          category: newMenuItem.category
        }])
        .select()
        .single();

      if (error) {
        console.error('Error adding menu item:', error);
        toast({
          title: "Error",
          description: "Gagal menambahkan menu",
          variant: "destructive"
        });
      } else {
        const formattedItem = {
          id: data.id,
          name: data.name,
          url: data.url,
          icon: data.icon || "",
          description: data.description || "",
          category: data.category || "Umum"
        };
        setMenuItems([...menuItems, formattedItem]);
        setNewMenuItem({ name: "", url: "", icon: "", description: "", category: "" });
        toast({
          title: "Berhasil",
          description: "Menu baru telah ditambahkan"
        });
      }
    } catch (error) {
      console.error('Error adding menu item:', error);
    }
  };

  const handleAddAnnouncement = async () => {
    if (!newAnnouncement.title || !newAnnouncement.content) {
      toast({
        title: "Error", 
        description: "Judul dan konten pengumuman harus diisi",
        variant: "destructive"
      });
      return;
    }

    try {
      const { data, error } = await supabase
        .from('announcements')
        .insert([{
          title: newAnnouncement.title,
          content: newAnnouncement.content,
          is_important: newAnnouncement.isImportant
        }])
        .select()
        .single();

      if (error) {
        console.error('Error adding announcement:', error);
        toast({
          title: "Error",
          description: "Gagal menambahkan pengumuman",
          variant: "destructive"
        });
      } else {
        const formattedAnnouncement = {
          id: data.id,
          title: data.title,
          content: data.content,
          date: data.date,
          isImportant: data.is_important
        };
        setAnnouncements([formattedAnnouncement, ...announcements]);
        setNewAnnouncement({ title: "", content: "", isImportant: false });
        toast({
          title: "Berhasil",
          description: "Pengumuman baru telah ditambahkan"
        });
      }
    } catch (error) {
      console.error('Error adding announcement:', error);
    }
  };

  const handleDeleteMenuItem = async (id: string) => {
    try {
      const { error } = await supabase
        .from('menu_items')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting menu item:', error);
        toast({
          title: "Error",
          description: "Gagal menghapus menu",
          variant: "destructive"
        });
      } else {
        setMenuItems(menuItems.filter(item => item.id !== id));
        toast({
          title: "Berhasil",
          description: "Menu telah dihapus"
        });
      }
    } catch (error) {
      console.error('Error deleting menu item:', error);
    }
  };

  const handleDeleteAnnouncement = async (id: string) => {
    try {
      const { error } = await supabase
        .from('announcements')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting announcement:', error);
        toast({
          title: "Error",
          description: "Gagal menghapus pengumuman",
          variant: "destructive"
        });
      } else {
        setAnnouncements(announcements.filter(item => item.id !== id));
        toast({
          title: "Berhasil", 
          description: "Pengumuman telah dihapus"
        });
      }
    } catch (error) {
      console.error('Error deleting announcement:', error);
    }
  };

  const handleEditMenuItem = async (item: MenuItem) => {
    try {
      const { error } = await supabase
        .from('menu_items')
        .update({
          name: item.name,
          url: item.url,
          icon: item.icon,
          description: item.description,
          category: item.category
        })
        .eq('id', item.id);

      if (error) {
        console.error('Error updating menu item:', error);
        toast({
          title: "Error",
          description: "Gagal memperbarui menu",
          variant: "destructive"
        });
      } else {
        const index = menuItems.findIndex(m => m.id === item.id);
        if (index !== -1) {
          const updated = [...menuItems];
          updated[index] = item;
          setMenuItems(updated);
          setEditingItem(null);
          toast({
            title: "Berhasil",
            description: "Menu telah diperbarui"
          });
        }
      }
    } catch (error) {
      console.error('Error updating menu item:', error);
    }
  };

  const handleEditAnnouncement = async (item: Announcement) => {
    try {
      const { error } = await supabase
        .from('announcements')
        .update({
          title: item.title,
          content: item.content,
          is_important: item.isImportant
        })
        .eq('id', item.id);

      if (error) {
        console.error('Error updating announcement:', error);
        toast({
          title: "Error",
          description: "Gagal memperbarui pengumuman",
          variant: "destructive"
        });
      } else {
        const index = announcements.findIndex(a => a.id === item.id);
        if (index !== -1) {
          const updated = [...announcements];
          updated[index] = item;
          setAnnouncements(updated);
          setEditingAnnouncement(null);
          toast({
            title: "Berhasil",
            description: "Pengumuman telah diperbarui"
          });
        }
      }
    } catch (error) {
      console.error('Error updating announcement:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-blue-500 rounded-xl flex items-center justify-center mx-auto mb-6 animate-pulse shadow-lg">
            <div className="w-8 h-8 bg-white rounded-lg"></div>
          </div>
          <p className="text-gray-600 font-medium text-lg">Memuat SISPENDA...</p>
          <div className="mt-4 w-48 h-2 bg-gray-200 rounded-full mx-auto overflow-hidden">
            <div className="h-full bg-blue-500 rounded-full animate-pulse w-3/4"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">S</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">SISPENDA</h1>
                <p className="text-xs text-gray-600">SMP Negeri 2 Tungkal Jaya</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-gray-600 hover:text-blue-600">
                    <Info className="w-5 h-5" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-white max-w-lg">
                  <DialogHeader>
                    <DialogTitle className="text-lg font-semibold text-gray-900 flex items-center">
                      <BookOpen className="w-5 h-5 mr-2" />
                      Tentang SISPENDA
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-6">
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <User className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900 mb-1">Pengembang Aplikasi</h3>
                        <p className="text-gray-600">Rudy Susanto, S.Pd., Gr</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                        <FileText className="w-5 h-5 text-orange-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900 mb-2">Deskripsi</h3>
                        <p className="text-gray-600 leading-relaxed">
                          SISPENDA adalah aplikasi berbasis web yang dikembangkan khusus untuk para guru di SMP Negeri 2 Tungkal Jaya. 
                          Aplikasi ini berfungsi sebagai pusat informasi dan akses cepat ke berbagai menu penting yang disediakan. 
                          Semoga Bermanfaat.
                        </p>
                      </div>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              {!isAdminMode ? (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm" className="text-gray-600">
                      <Settings className="w-5 h-5" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-white">
                    <DialogHeader>
                      <DialogTitle className="text-lg font-semibold text-gray-900">Login Admin</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <Input
                        type="password"
                        placeholder="Password admin"
                        value={adminPassword}
                        onChange={(e) => setAdminPassword(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleAdminLogin()}
                      />
                      <Button onClick={handleAdminLogin} className="w-full bg-blue-500 hover:bg-blue-600">
                        Login
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              ) : (
                <div className="flex items-center space-x-3">
                  <Badge variant="secondary" className="bg-green-50 text-green-700 border border-green-200">
                    <Users className="w-3 h-3 mr-1" />
                    Admin Mode
                  </Badge>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setIsAdminMode(false)}
                    className="text-gray-600"
                  >
                    Logout
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-12 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-50 via-white to-blue-50 rounded-3xl opacity-50"></div>
          <div className="absolute inset-0 opacity-10">
            <div className="w-full h-full bg-gradient-to-br from-blue-100 to-transparent" style={{
              backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(59, 130, 246, 0.1) 10px, rgba(59, 130, 246, 0.1) 20px),
                               repeating-linear-gradient(-45deg, transparent, transparent 10px, rgba(30, 64, 175, 0.05) 10px, rgba(30, 64, 175, 0.05) 20px)`,
              borderRadius: '1.5rem'
            }}></div>
          </div>
          <div className="relative py-16 px-8">
            <h2 
              className="text-3xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent"
              style={{
                textShadow: '0 0 0 #3b82f6, 1px 1px 0 #1e40af, 2px 2px 0 #1e3a8a',
                WebkitTextStroke: '1px #2563eb',
                fontSize: '30px'
              }}
            >
              Selamat Datang di SISPENDA
            </h2>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto font-medium">
              Sistem Informasi SMP Negeri 2 Tungkal Jaya
            </p>
            <div className="mt-6 w-24 h-1 bg-gradient-to-r from-blue-400 to-blue-600 mx-auto rounded-full"></div>
          </div>
        </div>

        {/* Single Column Layout - Announcements at Top, Menu Apps Below */}
        <div className="space-y-12">
          {/* Announcements Section */}
          {(
            <div className="max-w-4xl mx-auto animate-fade-in">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-gray-900 flex items-center">
                  <div className="w-6 h-6 bg-orange-500 rounded-lg flex items-center justify-center mr-2">
                    <Megaphone className="w-3 h-3 text-white" />
                  </div>
                  Pengumuman
                </h3>
                {isAdminMode && (
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button size="sm" className="bg-orange-500 hover:bg-orange-600">
                        <Plus className="w-4 h-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-white max-w-4xl">
                      <DialogHeader>
                        <DialogTitle className="text-lg font-semibold text-gray-900">Tambah Pengumuman</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <Input
                          placeholder="Judul pengumuman"
                          value={newAnnouncement.title}
                          onChange={(e) => setNewAnnouncement({...newAnnouncement, title: e.target.value})}
                        />
                        <RichTextEditor
                          value={newAnnouncement.content}
                          onChange={(content) => setNewAnnouncement({...newAnnouncement, content})}
                          placeholder="Konten pengumuman"
                        />
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="important"
                            checked={newAnnouncement.isImportant}
                            onChange={(e) => setNewAnnouncement({...newAnnouncement, isImportant: e.target.checked})}
                            className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                          />
                          <label htmlFor="important" className="text-sm font-medium text-gray-700">Pengumuman Penting</label>
                        </div>
                        <Button onClick={handleAddAnnouncement} className="w-full bg-orange-500 hover:bg-orange-600">
                          Tambah Pengumuman
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                )}
              </div>

              <div className="space-y-4">
                {announcements.map((announcement) => (
                  <div key={announcement.id} className="relative">
                    <AnnouncementCard
                      announcement={announcement}
                      isAdminMode={isAdminMode}
                      onEdit={setEditingAnnouncement}
                      onDelete={handleDeleteAnnouncement}
                      onClick={setSelectedAnnouncement}
                    />
                    {isNewAnnouncement(announcement.date) && (
                      <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-2 py-1">
                        NEW
                      </Badge>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Menu Applications Section */}
          <div>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900 flex items-center">
                <div className="w-6 h-6 bg-blue-500 rounded-lg flex items-center justify-center mr-2">
                  <i className="fas fa-th-large text-white text-xs"></i>
                </div>
                Menu Aplikasi
              </h3>
              {isAdminMode && (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button className="bg-blue-500 hover:bg-blue-600">
                      <Plus className="w-4 h-4 mr-2" />
                      Tambah Menu
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-white">
                    <DialogHeader>
                      <DialogTitle className="text-lg font-semibold text-gray-900">Tambah Menu Baru</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <Input
                        placeholder="Nama menu"
                        value={newMenuItem.name}
                        onChange={(e) => setNewMenuItem({...newMenuItem, name: e.target.value})}
                      />
                      <Input
                        placeholder="URL/Link"
                        value={newMenuItem.url}
                        onChange={(e) => setNewMenuItem({...newMenuItem, url: e.target.value})}
                      />
                      <Input
                        placeholder="Kategori (contoh: Akademik, Administrasi)"
                        value={newMenuItem.category}
                        onChange={(e) => setNewMenuItem({...newMenuItem, category: e.target.value})}
                      />
                      <Input
                        placeholder="Ikon Font Awesome (contoh: fas fa-home)"
                        value={newMenuItem.icon}
                        onChange={(e) => setNewMenuItem({...newMenuItem, icon: e.target.value})}
                      />
                      <Input
                        placeholder="Deskripsi (opsional)"
                        value={newMenuItem.description}
                        onChange={(e) => setNewMenuItem({...newMenuItem, description: e.target.value})}
                      />
                      <Button onClick={handleAddMenuItem} className="w-full bg-blue-500 hover:bg-blue-600">
                        Tambah Menu
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </div>

            {/* Search Menu */}
            <div className="mb-6">
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Cari menu..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Menu Items by Category */}
            <div className="space-y-8">
              {Object.entries(groupedMenuItems).map(([category, items]) => (
                <div key={category}>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <div className="w-1 h-6 bg-blue-500 rounded mr-3"></div>
                    {category}
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {items.map((item) => (
                      <MenuCard
                        key={item.id}
                        item={item}
                        isAdminMode={isAdminMode}
                        onEdit={setEditingItem}
                        onDelete={handleDeleteMenuItem}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-20 text-center">
          <div className="bg-white rounded-xl shadow-sm p-8 border">
            <div className="flex items-center justify-center mb-4">
              <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center shadow-lg mr-3">
                <span className="text-white font-bold text-sm">S</span>
              </div>
              <h4 className="text-xl font-bold text-blue-600">
                SISPENDA
              </h4>
            </div>
            <p className="text-gray-600 mb-8">
              Pusat informasi dan akses layanan digital untuk para guru SMP Negeri 2 Tungkal Jaya
            </p>
            
            <div className="mb-8">
              <Dialog>
                <DialogTrigger asChild>
                  <Button 
                    variant="outline" 
                    className="text-blue-600 border-blue-500 hover:bg-blue-50 hover:border-blue-600 transition-all duration-200"
                  >
                    <Info className="w-4 h-4 mr-2" />
                    Tentang Aplikasi
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-white max-w-lg">
                  <DialogHeader>
                    <DialogTitle className="text-lg font-semibold text-gray-900 flex items-center">
                      <BookOpen className="w-5 h-5 mr-2" />
                      Tentang SISPENDA
                    </DialogTitle>
                  </DialogHeader>
                  <div className="space-y-6">
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <User className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900 mb-1">Pengembang Aplikasi</h3>
                        <p className="text-gray-600">Rudy Susanto, S.Pd., Gr</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                        <FileText className="w-5 h-5 text-orange-600" />
                      </div>
                      <div>
                        <h3 className="font-medium text-gray-900 mb-2">Deskripsi</h3>
                        <p className="text-gray-600 leading-relaxed">
                          SISPENDA adalah aplikasi berbasis web yang dikembangkan khusus untuk para guru di SMP Negeri 2 Tungkal Jaya. 
                          Aplikasi ini berfungsi sebagai pusat informasi dan akses cepat ke berbagai menu penting yang disediakan. 
                          Semoga Bermanfaat.
                        </p>
                      </div>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            
            <div className="text-sm text-gray-500">
              © 2025 SISPENDA. Dikembangkan oleh <span className="font-medium">Rudy Susanto</span>
            </div>
          </div>
        </div>
      </main>

      {/* Modals */}
      <Dialog open={!!selectedAnnouncement} onOpenChange={() => setSelectedAnnouncement(null)}>
        <DialogContent className="bg-white max-w-4xl max-h-[80vh] overflow-y-auto">
          {selectedAnnouncement && (
            <>
              <DialogHeader>
                <div className="flex items-center space-x-3">
                  <DialogTitle className="text-xl font-bold text-gray-900 flex-1">
                    {selectedAnnouncement.title}
                  </DialogTitle>
                  {selectedAnnouncement.isImportant && (
                    <Badge className="bg-orange-500 text-white border-orange-600">
                      <i className="fas fa-exclamation-triangle mr-1"></i>
                      Penting
                    </Badge>
                  )}
                </div>
                <div className="flex items-center text-sm text-gray-500 mt-2">
                  <i className="fas fa-calendar-alt mr-2 text-blue-500"></i>
                  {new Date(selectedAnnouncement.date).toLocaleDateString('id-ID', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </div>
              </DialogHeader>
              <div 
                className="prose prose-slate max-w-none mt-4"
                dangerouslySetInnerHTML={{ __html: selectedAnnouncement.content }}
              />
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Announcement Modal */}
      <Dialog open={!!editingAnnouncement} onOpenChange={() => setEditingAnnouncement(null)}>
        <DialogContent className="bg-white max-w-4xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-gray-900">Edit Pengumuman</DialogTitle>
          </DialogHeader>
          {editingAnnouncement && (
            <div className="space-y-4">
              <Input
                placeholder="Judul pengumuman"
                value={editingAnnouncement.title}
                onChange={(e) => setEditingAnnouncement({...editingAnnouncement, title: e.target.value})}
              />
              <RichTextEditor
                value={editingAnnouncement.content}
                onChange={(content) => setEditingAnnouncement({...editingAnnouncement, content})}
                placeholder="Konten pengumuman"
              />
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id={`important-${editingAnnouncement.id}`}
                  checked={editingAnnouncement.isImportant}
                  onChange={(e) => setEditingAnnouncement({...editingAnnouncement, isImportant: e.target.checked})}
                  className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                />
                <label htmlFor={`important-${editingAnnouncement.id}`} className="text-sm font-medium text-gray-700">Pengumuman Penting</label>
              </div>
              <Button onClick={() => handleEditAnnouncement(editingAnnouncement)} className="w-full bg-orange-500 hover:bg-orange-600">
                Simpan Perubahan
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Menu Modal */}
      <Dialog open={!!editingItem} onOpenChange={() => setEditingItem(null)}>
        <DialogContent className="bg-white">
          <DialogHeader>
            <DialogTitle className="text-lg font-semibold text-gray-900">Edit Menu</DialogTitle>
          </DialogHeader>
          {editingItem && (
            <div className="space-y-4">
              <Input
                placeholder="Nama menu"
                value={editingItem.name}
                onChange={(e) => setEditingItem({...editingItem, name: e.target.value})}
              />
              <Input
                placeholder="URL/Link"
                value={editingItem.url}
                onChange={(e) => setEditingItem({...editingItem, url: e.target.value})}
              />
              <Input
                placeholder="Kategori"
                value={editingItem.category || ""}
                onChange={(e) => setEditingItem({...editingItem, category: e.target.value})}
              />
              <Input
                placeholder="Ikon Font Awesome (contoh: fas fa-home)"
                value={editingItem.icon}
                onChange={(e) => setEditingItem({...editingItem, icon: e.target.value})}
              />
              <Input
                placeholder="Deskripsi (opsional)"
                value={editingItem.description || ""}
                onChange={(e) => setEditingItem({...editingItem, description: e.target.value})}
              />
              <Button onClick={() => handleEditMenuItem(editingItem)} className="w-full bg-blue-500 hover:bg-blue-600">
                Simpan Perubahan
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Index;
